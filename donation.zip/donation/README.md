ContentBox Donation Module
=================

Author
-----------------
Computer Know How/Seth Engen

Description
-----------------
This module will generate Stripe donation forms for your ContentBox websites.

Installation
-----------------
Drop the 'donation' folder into your modules/contentbox/modules_user folder within your ContentBox enabled application, or install via the ContentBox Modules ForgeBox link.

Usage
-----------------
Setup your stripe keys in the donation settings page in the ContentBox admin then add a donation form to your page with the ContentBox widget button in CKEditor.

Change Log
-----------------
* Version 1.1  - Updated for ContentBox 3
* Version 1.0  - Initial Release